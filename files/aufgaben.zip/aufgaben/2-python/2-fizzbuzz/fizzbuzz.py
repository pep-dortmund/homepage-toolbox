
# encoding: utf-8
from __future__ import (print_function,
                        division,
                        unicode_literals,
                        absolute_import)


for n in range(1, 101):
    # Programm ergänzen / ändern
    print(n)
