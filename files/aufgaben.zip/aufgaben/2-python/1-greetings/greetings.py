
# encoding: utf-8
from __future__ import (print_function,
                        division,
                        unicode_literals,
                        absolute_import)

names = ['World', 'Toolbox Workshop', 'Kevin']


# hier ergänzen





# Gewünschte Ausgabe:
# Hello World
# Hello Toolbox Workshop
# Hello Kevin
