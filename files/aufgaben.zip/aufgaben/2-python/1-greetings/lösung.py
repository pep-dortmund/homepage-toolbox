
# encoding: utf-8
from __future__ import (print_function,
                        division,
                        unicode_literals,
                        absolute_import)

names = ['World', 'Toolbox Workshop', 'Kevin']

for name in names:
    print('Hello ' + name)

