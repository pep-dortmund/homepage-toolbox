import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import curve_fit
from scipy.signal import find_peaks


# parameters_max = #
# parameters_min = #

# Dieser Code erzeugt den Plot
fig, ax = plt.subplots(1, 1, layout="constrained")

x = np.linspace(0, ax.get_xlim()[1], 500)

ax.plot(t, U, "k-", label="Gedämpfte Schwingung")

ax.plot(x, e(x, *parameters_max), "g-", label="Obere Einhüllende")
ax.plot(t[maxs], U[maxs], "o", color="C0", label="Maxima")

ax.plot(x, e(x, *parameters_min), "y-", label="Untere Einhüllende")
ax.plot(t[mins], U[mins], "o", color="C1", label="Minima")

ax.set_xlabel(r"$t \ / \ \mathrm{ms}$")
ax.set_ylabel(r"$U \ / \ \mathrm{V}$")
ax.set_xlim(0, 0.3)
ax.legend()
fig.savefig("loesung.pdf")
