# Für die 1. und 2. Aufgabe:
title = "Wiegen von Metallen"
date = "24.09.2018"

# Für die 3. Aufgabe:
metals = ["Eisen", "Kupfer", "Zink", "Blei"]
masses = [9.1, 10.29, 12.485, 130.01]

# Für die 1. Aufgabe:
print()
# Gewünschte Ausgabe:
# Versuch: Wiegen von Metallen durchgeführt am 24.09.2018

# print()
# Ausgabe mit Anführungszeichen:
# Versuch 'Wiegen von Metallen' durchgeführt am 24.09.2018

# Für die 2.Aufgabe
print(f"")

# Für die 3. Aufgabe

for metal, mass in zip(metals, masses):
    print()

# Gewünschte Aufgabe:
# Eisen: 9.1
# Kupfer: 10.29
# Zink: 12.485
# Blei: 130.01

