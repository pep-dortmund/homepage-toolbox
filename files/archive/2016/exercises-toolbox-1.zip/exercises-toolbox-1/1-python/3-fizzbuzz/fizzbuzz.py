for n in range(1, 101):
    # Programm ergänzen / ändern
    print(n)
