data = [42, 3.1415, 2.7182, 1, 2]

# Hier den Mittelwert berechnen und ausgeben
