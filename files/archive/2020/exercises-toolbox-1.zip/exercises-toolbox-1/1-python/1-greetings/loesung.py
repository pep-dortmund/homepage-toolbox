names = ['World', 'Toolbox Workshop', 'Kevin']

for name in names:
    print('Hello ' + name)
