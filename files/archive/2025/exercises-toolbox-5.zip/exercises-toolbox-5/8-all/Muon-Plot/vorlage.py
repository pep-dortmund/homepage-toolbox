import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import curve_fit
from uncertainties import correlated_values
import uncertainties.unumpy as unp

noms = unp.nominal_values
stds = unp.std_devs

t = (2 * np.arange(110) + 5) / 21.48
