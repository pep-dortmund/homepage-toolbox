

# Dieser Code erstellt einen Plot mithilfe von f und parameters
fig = plt.figure(layout="constrained")
ax = fig.add_subplot()

ax.errorbar(x, y, yerr=e_y, fmt="k.", label="data")

t = np.linspace(-10, 10, 500)
ax.plot(t, f(t, *parameters), label="Fit")
ax.plot(t, t**2, "--", label="Original")

ax.set_xlim(t[0], t[-1])
ax.set_xlabel(r"$t$")
ax.set_ylabel(r"$f(t)$")
ax.legend()

plt.savefig("loesung.pdf")
# end solution
