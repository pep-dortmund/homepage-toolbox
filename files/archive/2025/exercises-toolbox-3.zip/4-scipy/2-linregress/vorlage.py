import numpy as np


def linregress(x, y):
    # …
    return A, A_error, B, B_error


