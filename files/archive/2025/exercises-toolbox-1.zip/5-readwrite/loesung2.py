# begin solution
with open("test.txt", "w") as f:
    f.write(str(42))
# end solution
