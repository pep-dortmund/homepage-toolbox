histogram([6, 2, -1, 10, 1, 8])
