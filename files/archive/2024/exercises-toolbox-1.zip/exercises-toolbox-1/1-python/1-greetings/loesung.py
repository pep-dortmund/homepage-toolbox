names = ["World", "Toolbox Workshop", "Kevin"]


# hier ergänzen
# begin solution
for name in names:
    print("Hello " + name)
# end solution

# Gewünschte Ausgabe:
# Hello World
# Hello Toolbox Workshop
# Hello Kevin
# Hello <Dein Name>
