names = ["World", "Toolbox Workshop", "Kevin"]


# hier ergänzen

# Gewünschte Ausgabe:
# Hello World
# Hello Toolbox Workshop
# Hello Kevin
# Hello <Dein Name>
