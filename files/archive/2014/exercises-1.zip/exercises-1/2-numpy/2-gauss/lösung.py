
from numpy.random import randn

xs = 1 + 2 * randn(1000)
print('Summe: ', sum(xs))


