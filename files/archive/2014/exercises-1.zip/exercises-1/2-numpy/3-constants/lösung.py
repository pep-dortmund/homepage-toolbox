
from scipy.constants import find, physical_constants

name = find('boltzmann')[0]
print(name)
print(physical_constants[name])

