data = [42, 3.1415, 2.7182, 1, 2]

avg = sum(data) / len(data)

print('Der Mittelwert ist ', avg)
