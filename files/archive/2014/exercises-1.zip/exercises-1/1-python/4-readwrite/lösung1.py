with open('test.txt') as f:
    print(f.read())
