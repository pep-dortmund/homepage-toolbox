#! /usr/bin/env python
# encoding: utf-8


import numpy as np

A = np.arange(5)

# Lösung zu 1) hier:




B = np.array([[2, 1, 2, 1, 2], [1, 2, 1, 2, 1], [3, 1, 3, 1, 3]])

# Lösung zu 2) hier:



# Lösung zu 3) hier:
