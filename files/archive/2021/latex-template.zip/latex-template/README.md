# Vorlage für Praktikumsprotokolle


Dieser Ordner enthält die Struktur für Praktikumsprotokolle mit
allem, was in diesem Kurs besprochen wurde.

In Basisordner liegt der LaTeX-Header, Literaturdatenbank (`lit.bib`) sowie die der LaTeX-Header für matplotlib
und die matplotlibrc.
Außerdem haben wir in `programme.bib` die korrekten Quellen für die verwendete Software angegeben.

In dem Unterordner `vXXX` liegt dann ein Template für einen einzelnen Versuch,
welches für die jeweiligen Versuche kopiert und „ausgefüllt“ werden kann.
