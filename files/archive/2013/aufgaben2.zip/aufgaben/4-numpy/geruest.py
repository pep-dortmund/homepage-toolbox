# encoding: utf-8
from __future__ import (print_function,
                        division,
                        unicode_literals,
                        absolute_import)

import numpy as np
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt
