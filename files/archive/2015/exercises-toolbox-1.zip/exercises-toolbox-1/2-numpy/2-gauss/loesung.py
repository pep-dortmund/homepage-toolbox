import numpy as np

xs = np.random.normal(1, 2, size=1000)
print('Summe: ', np.sum(xs))
